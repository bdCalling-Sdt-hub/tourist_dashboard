export const UpdatePasswordFields = [
    {
        name: 'oldPassword',
        label: 'Current Password',
        placeholder: 'insert your password',
        required: true,
        message: 'please input your password',
        type: 'password',
    },
    {
        name: 'newPassword',
        label: 'New Password',
        placeholder: 'insert your password',
        required: true,
        message: 'please input your password',
        type: 'password',
    },
    {
        name: 'confirmPassword',
        label: 'Confirm New Password',
        placeholder: 'insert your Confirm password',
        required: true,
        message: 'please input your Confirm password',
        type: 'password',
    },
]