import { baseApi } from "../BaseUrl";

const dashboardApi = baseApi.injectEndpoints({
    //  get dashboard data 
    endpoints: (builder) => ({
        getDashboardData: builder.query({
            query: () => ({ url: 'dashboard/overview', method: 'GET' }),
            providesTags: ['dashboard']
        }),
        getIncomeOverview: builder.query({
            query: (year) => ({ url: `overview/income-overview?year=${year}`, method: 'GET' }),
            providesTags: ['dashboard']
        }),
        getClickOverview: builder.query({
            query: () => ({ url: `/events/click-overview`, method: 'GET' }),
            providesTags: ['dashboard']
        }),
    })
});

export const {
    // useGetDashboardDataQuery
    useGetDashboardDataQuery,
    // useGetIncomeOverviewQuery
    useGetIncomeOverviewQuery,
    // useGetAppointmentOverviewQuery
    useGetClickOverviewQuery

} = dashboardApi