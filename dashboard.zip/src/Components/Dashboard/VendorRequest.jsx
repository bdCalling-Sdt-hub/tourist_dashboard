import React from 'react'
import RequestTable from '../VendorRequest/RequestTable'

const VendorRequest = () => {
    return (
        <div className='bg-white'>
            <RequestTable />
        </div>
    )
}

export default VendorRequest
